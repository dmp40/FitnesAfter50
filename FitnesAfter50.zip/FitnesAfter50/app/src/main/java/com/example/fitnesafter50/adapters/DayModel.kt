package com.example.fitnesafter50.adapters

data class DayModel(
    var exercises: String,
    var isDone: Boolean
)
