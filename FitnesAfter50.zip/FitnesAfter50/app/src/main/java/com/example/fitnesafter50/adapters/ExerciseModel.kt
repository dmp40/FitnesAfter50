package com.example.fitnesafter50.adapters

 data class ExerciseModel (
     var name:String,
     var time:String,
     var image:String,
         )
