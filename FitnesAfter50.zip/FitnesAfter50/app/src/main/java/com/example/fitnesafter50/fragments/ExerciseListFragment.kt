package com.example.fitnesafter50.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnesafter50.R
import com.example.fitnesafter50.adapters.DayModel
import com.example.fitnesafter50.adapters.DaysAdapter
import com.example.fitnesafter50.adapters.ExerciseAdapter
import com.example.fitnesafter50.databinding.ExerciceListFragmentBinding
import com.example.fitnesafter50.databinding.FragmentDaysBinding
import utils.MainViewModels


class ExerciseListFragment : Fragment() {

 private lateinit var binding: ExerciceListFragmentBinding
 private lateinit var adapter: ExerciseAdapter
    private val model: MainViewModels by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = ExerciceListFragmentBinding.inflate(inflater,container, false)
        return  binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
        model.mutableListExercise.observe(viewLifecycleOwner){
            
        }

    }

    private fun init() = with(binding){
        adapter = ExerciseAdapter()
        rcView.layoutManager = LinearLayoutManager(activity)
         rcView.adapter = adapter
    }


    companion object {

        @JvmStatic
        fun newInstance() = ExerciseListFragment()
    }
}