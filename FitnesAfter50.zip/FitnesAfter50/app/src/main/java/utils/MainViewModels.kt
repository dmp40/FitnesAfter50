package utils

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.fitnesafter50.adapters.ExerciseModel

class MainViewModels  : ViewModel (){
    val  mutableListExercise  = MutableLiveData<ArrayList<ExerciseModel>>()
}